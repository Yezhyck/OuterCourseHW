package model;

public enum Group {
    ADMIN,
    MANAGER,
    USER,
    UNKNOWN
}
